<?php

use Illuminate\Support\Facades\Route;
// routes/web.php

use App\Http\Controllers\PokemonController;

Route::resource('pokemons', PokemonController::class);


?>

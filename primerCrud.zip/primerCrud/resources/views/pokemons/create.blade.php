<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Crear Pokémon</div>
                    <div class="card-body">
                        <form action="{{ route('pokemons.store') }}" method="POST">
                            @csrf

                            <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="tipo">Tipo:</label>
                                <select name="tipo" class="form-control" required>
                                    <option value="Agua">Agua</option>
                                    <option value="Fuego">Fuego</option>
                                    <option value="Planta">Planta</option>
                                    <option value="Electrico">Electrico</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tamaño">Tamaño:</label>
                                <select name="tamaño" class="form-control" required>
                                    <option value="pequeño">Pequeño</option>
                                    <option value="mediano">Mediano</option>
                                    <option value="grande">Grande</option>
                                </select>
                            </div>
--faltaria algo para no poder poner pesos en negativo 
                            <div class="form-group">
                                <label for="peso">Peso:</label>
                                <input type="number" step="0.01" name="peso" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
</html>
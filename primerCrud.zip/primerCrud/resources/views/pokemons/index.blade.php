<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="my-4">Listado de Pokémon</h1>

        <a href="{{ route('pokemons.create') }}" class="btn btn-primary mb-3">Crear Pokémon</a>

        <table class="table">
            
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    
                </tr>
            </thead>
            <tbody>
                @foreach($pokemons as $pokemon)
                    <tr>
                        <td>{{ $pokemon->id }}</td>
                        <td>{{ $pokemon->nombre }}</td>
                        
                        <td>
                            <a href="{{ route('pokemons.show', $pokemon->id) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('pokemons.edit', $pokemon->id) }}" class="btn btn-warning btn-sm">Editar</a>
                            <form action="{{ route('pokemons.destroy', $pokemon->id) }}" method="POST" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

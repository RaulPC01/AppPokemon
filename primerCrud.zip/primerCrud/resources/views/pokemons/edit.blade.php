
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar Pokémon</div>
                    <div class="card-body">
                        <form action="{{ route('pokemons.update', $pokemon->id) }}" method="POST">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" class="form-control" value="{{ $pokemon->nombre }}" required>
                            </div>

                            <div class="form-group">
                                <label for="tipo">Tipo:</label>
                                <select name="tipo" class="form-control" required>
                                    <option value="Agua" {{ $pokemon->tipo == 'Agua' ? 'selected' : '' }}>Agua</option>
                                    <option value="Fuego" {{ $pokemon->tipo == 'Fuego' ? 'selected' : '' }}>Fuego</option>
                                    <option value="Planta" {{ $pokemon->tipo == 'Planta' ? 'selected' : '' }}>Planta</option>
                                    <option value="Electrico" {{ $pokemon->tipo == 'Electrico' ? 'selected' : '' }}>Planta</option>
                                    
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tamaño">Tamaño:</label>
                                <select name="tamaño" class="form-control" required>
                                    <option value="pequeño" {{ $pokemon->tamaño == 'pequeño' ? 'selected' : '' }}>Pequeño</option>
                                    <option value="mediano" {{ $pokemon->tamaño == 'mediano' ? 'selected' : '' }}>Mediano</option>
                                    <option value="grande" {{ $pokemon->tamaño == 'grande' ? 'selected' : '' }}>Grande</option>
                                </select>
                            </div>
--poner que no pueda ser negativo el peso
                            <div class="form-group">
                                <label for="peso">Peso:</label>
                                <input type="number" step="0.01" name="peso" class="form-control" value="{{ $pokemon->peso }}" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Guardar cambios</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

@extends('layouts.app')

@section('content')
    <div class="container">
        <h1 class="my-4">Detalles del Pokémon</h1>

        <div class="card">
            <div class="card-body">
                <ul class="list-group">
                    <li class="list-group-item"><strong>ID:</strong> {{ $pokemon->id }}</li>
                    <li class="list-group-item"><strong>Nombre:</strong> {{ $pokemon->nombre }}</li>
                    <li class="list-group-item"><strong>Tipo:</strong> {{ $pokemon->tipo }}</li>
                    <li class="list-group-item"><strong>Tamaño:</strong> {{ $pokemon->tamaño }}</li>
                    <li class="list-group-item"><strong>Peso:</strong> {{ $pokemon->peso }}</li>
                </ul>
            </div>
        </div>

        <a href="{{ route('pokemons.index') }}" class="btn btn-primary mt-3">Volver al listado</a>
    </div>
@endsection

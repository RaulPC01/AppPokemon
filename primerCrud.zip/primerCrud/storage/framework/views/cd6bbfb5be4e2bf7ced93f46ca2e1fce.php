
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar Pokémon</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('pokemons.update', $pokemon->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" class="form-control" value="<?php echo e($pokemon->nombre); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="tipo">Tipo:</label>
                                <select name="tipo" class="form-control" required>
                                    <option value="Agua" <?php echo e($pokemon->tipo == 'Agua' ? 'selected' : ''); ?>>Agua</option>
                                    <option value="Fuego" <?php echo e($pokemon->tipo == 'Fuego' ? 'selected' : ''); ?>>Fuego</option>
                                    <option value="Planta" <?php echo e($pokemon->tipo == 'Planta' ? 'selected' : ''); ?>>Planta</option>
                                    <!-- Agrega más tipos según tus necesidades -->
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tamaño">Tamaño:</label>
                                <select name="tamaño" class="form-control" required>
                                    <option value="pequeño" <?php echo e($pokemon->tamaño == 'pequeño' ? 'selected' : ''); ?>>Pequeño</option>
                                    <option value="mediano" <?php echo e($pokemon->tamaño == 'mediano' ? 'selected' : ''); ?>>Mediano</option>
                                    <option value="grande" <?php echo e($pokemon->tamaño == 'grande' ? 'selected' : ''); ?>>Grande</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="peso">Peso:</label>
                                <input type="number" step="0.01" name="peso" class="form-control" value="<?php echo e($pokemon->peso); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Guardar cambios</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\primerCrud\resources\views/pokemons/edit.blade.php ENDPATH**/ ?>
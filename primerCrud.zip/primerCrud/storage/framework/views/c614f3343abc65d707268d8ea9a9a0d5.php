<!-- resources/views/pokemons/create.blade.php -->
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Crear Pokémon</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('pokemons.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="nombre">Nombre:</label>
                                <input type="text" name="nombre" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label for="tipo">Tipo:</label>
                                <select name="tipo" class="form-control" required>
                                    <option value="Agua">Agua</option>
                                    <option value="Fuego">Fuego</option>
                                    <option value="Planta">Planta</option>
                                    <option value="Electrico">Electrico</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="tamaño">Tamaño:</label>
                                <select name="tamaño" class="form-control" required>
                                    <option value="pequeño">Pequeño</option>
                                    <option value="mediano">Mediano</option>
                                    <option value="grande">Grande</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="peso">Peso:</label>
                                <input type="number" step="0.01" name="peso" class="form-control" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\primerCrud\resources\views/pokemons/create.blade.php ENDPATH**/ ?>
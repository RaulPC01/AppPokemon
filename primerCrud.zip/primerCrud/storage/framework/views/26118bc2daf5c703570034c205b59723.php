<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">




<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4">Listado de Pokémon</h1>

        <a href="<?php echo e(route('pokemons.create')); ?>" class="btn btn-primary mb-3">Crear Pokémon</a>

        <table class="table">
            
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pokemon->id); ?></td>
                        <td><?php echo e($pokemon->nombre); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('pokemons.show', $pokemon->id)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('pokemons.edit', $pokemon->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                            <form action="<?php echo e(route('pokemons.destroy', $pokemon->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\primerCrud\resources\views/pokemons/index.blade.php ENDPATH**/ ?>
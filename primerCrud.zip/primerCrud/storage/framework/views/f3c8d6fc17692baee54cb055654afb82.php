
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="my-4">Detalles del Pokémon</h1>

        <div class="card">
            <div class="card-body">
                <ul class="list-group">
                    <li class="list-group-item"><strong>ID:</strong> <?php echo e($pokemon->id); ?></li>
                    <li class="list-group-item"><strong>Nombre:</strong> <?php echo e($pokemon->nombre); ?></li>
                    <li class="list-group-item"><strong>Tipo:</strong> <?php echo e($pokemon->tipo); ?></li>
                    <li class="list-group-item"><strong>Tamaño:</strong> <?php echo e($pokemon->tamaño); ?></li>
                    <li class="list-group-item"><strong>Peso:</strong> <?php echo e($pokemon->peso); ?></li>
                </ul>
            </div>
        </div>

        <a href="<?php echo e(route('pokemons.index')); ?>" class="btn btn-primary mt-3">Volver al listado</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\primerCrud\resources\views/pokemons/show.blade.php ENDPATH**/ ?>